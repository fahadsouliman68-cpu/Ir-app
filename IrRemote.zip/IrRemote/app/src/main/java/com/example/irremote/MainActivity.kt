package com.example.irremote

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

data class Screen(val name: String, val proto: Proto, val addr: Int, val table: MutableMap<String, Int>)

class MainActivity : Activity() {
    private lateinit var ir: Ir
    private val handler = Handler(Looper.getMainLooper())
    private val screens = ArrayList<Screen>()
    private var atHome = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ir = Ir(this)
        load()
        showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!atHome) showHome() else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun text(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        gravity = Gravity.CENTER
        setPadding(0, dp(8), 0, dp(8))
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun btn(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(6), 0, dp(6)) }
        setOnClickListener { click() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            x.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(x)
        }
    }

    private fun page(build: LinearLayout.() -> Unit) {
        handler.removeCallbacksAndMessages(null)
        atHome = false
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        col.build()
        setContentView(ScrollView(this).apply { addView(col) })
    }

    // ---------- storage ----------
    private fun save() {
        val arr = JSONArray()
        for (s in screens) {
            arr.put(
                JSONObject().put("name", s.name).put("proto", s.proto.name).put("addr", s.addr)
                    .put("table", JSONObject(s.table as Map<*, *>))
            )
        }
        getSharedPreferences("ir", MODE_PRIVATE).edit().putString("screens", arr.toString()).apply()
    }

    private fun load() {
        screens.clear()
        val str = getSharedPreferences("ir", MODE_PRIVATE).getString("screens", "[]") ?: "[]"
        val arr = JSONArray(str)
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            val t = o.getJSONObject("table")
            val m = mutableMapOf<String, Int>()
            for (k in t.keys()) m[k] = t.getInt(k)
            screens.add(Screen(o.getString("name"), Proto.valueOf(o.getString("proto")), o.getInt("addr"), m))
        }
    }

    // ---------- screens ----------
    private fun showHome() {
        page {
            addView(text("ريموت الشاشات", 24f, true))
            if (!ir.available()) addView(text("⚠ هذا الهاتف لا يحتوي باعث IR", 16f, true))
            for (s in screens) addView(btn("📺 ${s.name}") { showRemote(s) })
            addView(btn("➕ إضافة شاشة") { askName() })
        }
        atHome = true
    }

    private fun askName() {
        val et = EditText(this)
        et.hint = "مثال: شاشة 1"
        AlertDialog.Builder(this)
            .setTitle("اسم الشاشة")
            .setView(et)
            .setPositiveButton("التالي") { _, _ ->
                val n = et.text.toString().ifBlank { "شاشة ${screens.size + 1}" }
                startAdd(n)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun startAdd(name: String) {
        scanner("بحث عن: $name", Brands.list, Brands.extended(), { c ->
            val table = if (c.table.isNotEmpty()) c.table.toMutableMap() else mutableMapOf("power" to c.cmd)
            val s = Screen(name, c.proto, c.addr, table)
            screens.add(s)
            save()
            showRemote(s)
        }, { showHome() })
    }

    private fun showRemote(s: Screen) {
        page {
            addView(text(s.name, 22f, true))
            addView(text("ضغطة قصيرة: إرسال\nضغطة طويلة: تعلّم / تغيير الزر", 13f))
            val keys = listOf(
                "power" to "⏻ تشغيل / إيقاف", "volup" to "🔊 صوت +", "voldown" to "🔉 صوت -",
                "mute" to "🔇 كتم", "chup" to "⏫ قناة +", "chdown" to "⏬ قناة -", "source" to "↪ المصدر"
            )
            for ((k, label) in keys) {
                val b = btn(label) {
                    val v = s.table[k]
                    if (v == null) toast("الزر غير معرّف، اضغط مطولاً لتعلّمه")
                    else ir.send(Code(s.proto, s.addr, v))
                }
                b.setOnLongClickListener { learn(s, k, label); true }
                addView(b)
            }
            addView(btn("🗑 حذف هذه الشاشة") {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("حذف ${s.name}؟")
                    .setPositiveButton("حذف") { _, _ -> screens.remove(s); save(); showHome() }
                    .setNegativeButton("إلغاء", null)
                    .show()
            })
            addView(btn("⬅ رجوع") { showHome() })
        }
    }

    private fun learn(s: Screen, key: String, label: String) {
        if (s.proto.maxCmd < 0) { toast("لا يمكن تعلّم أزرار هذه الشاشة"); return }
        val cands = (0..s.proto.maxCmd).map { Candidate("أمر رقم $it", s.proto, s.addr, it) }
        scanner("تعلّم: $label", cands, null, { c ->
            s.table[key] = c.cmd
            save()
            showRemote(s)
        }, { showRemote(s) })
    }

    // ---------- scanner ----------
    private fun scanner(
        title: String,
        initial: List<Candidate>,
        extended: List<Candidate>?,
        onSave: (Candidate) -> Unit,
        onCancel: () -> Unit
    ) {
        var list = initial
        var i = 0
        var auto = false
        var shown = false
        val delays = longArrayOf(1500, 1000, 500, 250)
        var di = 1
        val info = text("اضغط (ابدأ) لتبدأ التجربة", 18f, true)
        val autoBtn = btn("▶ ابدأ البحث التلقائي") {}
        val speedBtn = btn("") {}
        lateinit var tick: Runnable

        fun show() {
            shown = true
            info.text = "${list[i].label}\n(${i + 1} / ${list.size})"
            ir.send(list[i].code())
        }

        fun stopAuto() {
            auto = false
            handler.removeCallbacks(tick)
            autoBtn.text = "▶ تابع البحث التلقائي"
        }

        tick = Runnable {
            if (auto) {
                if (i < list.size - 1) {
                    i++
                    show()
                    handler.postDelayed(tick, delays[di])
                } else {
                    stopAuto()
                    info.text = "انتهت القائمة"
                }
            }
        }

        autoBtn.setOnClickListener {
            if (auto) stopAuto() else {
                auto = true
                autoBtn.text = "⏸ أوقف (الشاشة استجابت)"
                show()
                handler.postDelayed(tick, delays[di])
            }
        }

        fun speedText() = "السرعة: كل ${delays[di] / 1000.0} ثانية (اضغط للتغيير)"
        speedBtn.text = speedText()
        speedBtn.setOnClickListener { di = (di + 1) % delays.size; speedBtn.text = speedText() }

        val prev = btn("⏮ السابق") { stopAuto(); if (i > 0) i--; show() }
        val next = btn("⏭ التالي") { stopAuto(); if (i < list.size - 1) i++; show() }
        val again = btn("🔁 أعد") { stopAuto(); show() }
        val extBtn = btn("🔎 بحث موسّع (شركة غير معروفة)") {
            stopAuto()
            list = extended ?: list
            i = 0
            shown = false
            di = 2
            speedBtn.text = speedText()
            info.text = "بحث موسّع: ${list.size} كود\nاضغط (ابدأ)"
        }
        val saveBtn = btn("✅ احفظ هذا الكود") {
            if (!shown) toast("جرّب كوداً أولاً") else { stopAuto(); onSave(list[i]) }
        }

        page {
            addView(text(title, 20f, true))
            addView(text("وجّه الهاتف نحو الشاشة وراقبها.\nعندما تتغير حالة الشاشة اضغط (أوقف)، ثم استخدم ⏮ ⏭ 🔁 حتى تعرف الكود الصحيح، ثم احفظه.", 14f))
            addView(info)
            addView(autoBtn)
            addView(row(prev, again, next))
            addView(speedBtn)
            if (extended != null) addView(extBtn)
            addView(saveBtn)
            addView(btn("إلغاء") { stopAuto(); onCancel() })
        }
    }
}
